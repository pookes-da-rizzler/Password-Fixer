capital = 0
char_lan = 0
spec_s_missing = 0
weakness = 0

intro = '''
██████╗  ██████╗  ██████╗ ██╗  ██╗███████╗███████╗
██╔══██╗██╔═══██╗██╔═══██╗██║ ██╔╝██╔════╝██╔════╝
██████╔╝██║   ██║██║   ██║█████╔╝ █████╗  ███████╗
██╔═══╝ ██║   ██║██║   ██║██╔═██╗ ██╔══╝  ╚════██║
██║     ╚██████╔╝╚██████╔╝██║  ██╗███████╗███████║
╚═╝      ╚═════╝  ╚═════╝ ╚═╝  ╚═╝╚══════╝╚══════╝

██████╗  █████╗ ███████╗███████╗██╗    ██╗ ██████╗ ██████╗ ██████╗     ███████╗██╗██╗  ██╗
██╔══██╗██╔══██╗██╔════╝██╔════╝██║    ██║██╔═══██╗██╔══██╗██╔══██╗    ██╔════╝██║╚██╗██╔╝
██████╔╝███████║███████╗███████╗██║ █╗ ██║██║   ██║██████╔╝██║  ██║    █████╗  ██║ ╚███╔╝ 
██╔═══╝ ██╔══██║╚════██║╚════██║██║███╗██║██║   ██║██╔══██╗██║  ██║    ██╔══╝  ██║ ██╔██╗ 
██║     ██║  ██║███████║███████║╚███╔███╔╝╚██████╔╝██║  ██║██████╔╝    ██║     ██║██╔╝ ██╗
╚═╝     ╚═╝  ╚═╝╚══════╝╚══════╝ ╚══╝╚══╝  ╚═════╝ ╚═╝  ╚═╝╚═════╝     ╚═╝     ╚═╝╚═╝  ╚═╝

'''


def suggest():
    global weakness
    if capital == 0:
        print("************* There is no capital letter ************** \n")
        weakness += 1
    elif capital > 0:
        print("There is a capital letter \n")
    if char_lan == 1:
        print(
            "************* The password is bellow 8 characters *********** \n")
        weakness += 1
    elif char_lan == 0:
        print("The password is above 8 characters \n")
    if spec_s_missing == 1:
        print("************ There is no special character ************ \n")
        weakness += 1
    elif spec_s_missing == 0:
        print("There is a special character \n")


    vowels()
    print(f"The likeleyhood of this password to be wrong is: {weakness} /4"
          )  
    if weakness == 0 or weakness == 1:
        print("Try adding [*, !, @] at the end of your password if still incorrect \n")

    while True:
        print("\nWhat would you like to do:")
        print("1. Fix a password")
        print("2. Exit")
        choice = input("Enter 1 or 2: ")
        if choice == '1':
            passw()
        elif choice == '2':
            break
            quit()
        else:
            print("Invalid choice. Please enter 1, 2, 3, 4, 5, or 6.")


def vowels():
    global passw1, weakness
    for x in passw1:
        if x in 'aeiouAEIOU':
            print("**********There is a vowel************\n")
            print("These are some common alterations on vowels: \n")
            print("a -> @ -> A \n")
            print("e -> 3 -> E -> £ \n")
            print("i -> ! -> -> 1 -> I \n")
            print("o -> 0 -> O \n")
            print("u -> _ -> U \n")
            weakness += 1 
            break


def check():
    global passw1, capital, weakness

    def cap():
        global passw1, capital, weakness
        found_capital = False
        for x in passw1:
            caps = x.isupper()
            if caps:
                found_capital = True
        if found_capital:
            capital += 1

    def length():
        global passw1, char_lan, weakness
        if len(passw1) >= 8:
            char_lan += 0
        else:
            char_lan += 1

    def spec():
        global passw1, spec_s_missing, weakness
        for x in passw1:
            if x in '!@#$%^&*()_+=-,.<>1234567890': 
                spec_s_missing = 0
                break

    cap()
    length()
    spec()
    suggest()


def passw():
        print(f"{intro}\n")
        passw = input("Enter your password: ")
        print("\n")
        global passw1
        passw1 = list(passw)
        check()


passw()

suggest()
